package com.moiveapp.com.new_movie.Utils;

public class AppConstants {
    public static final String BASE_URL="https://api.themoviedb.org/3/movie/";
    public static final String API_KEY="37faa8bf84a71d12220f23afd6a27797";
    public static final String IMG_URL="http://image.tmdb.org/t/p/w200";
}
