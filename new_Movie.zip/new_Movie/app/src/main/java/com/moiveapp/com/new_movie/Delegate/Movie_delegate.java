package com.moiveapp.com.new_movie.Delegate;
import com.moiveapp.com.new_movie.model.Results;

public interface Movie_delegate {
    void delegateListener(Results results);
}
